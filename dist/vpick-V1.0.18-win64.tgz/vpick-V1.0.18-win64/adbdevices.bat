adb devices

